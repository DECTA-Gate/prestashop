<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{decta}prestashop>payment_02cf064329cf953914ae3b1db3477b86'] = 'Оплата банковской картой (Visa / Mastercard)';
$_MODULE['<{decta}prestashop>payment_return_091c355628c309a12c3e4858c6672582'] = 'Оплата прошла успешно, ваш заказ оформлен.';
$_MODULE['<{decta}prestashop>payment_return_d15feee53d81ea16269e54d4784fa123'] = 'Произошла ошибка при обработке вашего заказа. Свяжитесь с нашей';
$_MODULE['<{decta}prestashop>payment_return_66fcf4c223bbf4c7c886d4784e1f62e4'] = 'командой поддержки.';
