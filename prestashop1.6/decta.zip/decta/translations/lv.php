<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{decta}prestashop>payment_02cf064329cf953914ae3b1db3477b86'] = 'Maksāt ar bankas karti (Visa / Mastercard)';
$_MODULE['<{decta}prestashop>payment_return_091c355628c309a12c3e4858c6672582'] = 'Maksājums saņemts, jūsu pasūtījums ir pabeigts.';
$_MODULE['<{decta}prestashop>payment_return_d15feee53d81ea16269e54d4784fa123'] = 'Pamanījām problēmu ar jūsu pasūtījumu. Ja domājat, ka tā ir kļūda, sazinieties ar mūsu';
$_MODULE['<{decta}prestashop>payment_return_66fcf4c223bbf4c7c886d4784e1f62e4'] = 'atbalsta komandu.';
