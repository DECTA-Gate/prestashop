<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{decta}prestashop>decta_7bbd4f91b3ed903547dded2b8ae622c7'] = 'Decta';
$_MODULE['<{decta}prestashop>decta_93aca46997aa9cfea797fa6073078fd8'] = 'Принимайте оплату за товары с помощью банковских карт';
$_MODULE['<{decta}prestashop>decta_0f379daaee21894a7c6453950658fe8b'] = 'Вы уверены, что хотите удалить модуль?';
$_MODULE['<{decta}prestashop>decta_a02758d758e8bec77a33d7f392eb3f8a'] = 'Валюта для этого модуля не установлена.';
$_MODULE['<{decta}prestashop>decta_819225e8ef9e781e3ac6b0dc0bdc816f'] = 'Требуется открытый ключ.';
$_MODULE['<{decta}prestashop>decta_585c9619fa6c5a1040a8552aad5eec6e'] = 'Требуется закрытый ключ.';
$_MODULE['<{decta}prestashop>decta_32d6c06706f9a78b7bb9f3d144b7cb33'] = 'Параметр истечение срока обязателен.';
$_MODULE['<{decta}prestashop>decta_f881a1bd5ed581d563d30316fc764764'] = 'Параметр истечение срока  не может быть менее 5 минут.';
$_MODULE['<{decta}prestashop>decta_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{decta}prestashop>decta_02cf064329cf953914ae3b1db3477b86'] = 'Оплата картой Visa / Mastercard';
$_MODULE['<{decta}prestashop>decta_b4717f6ab3c2357c13c0c2cd32dfc4ca'] = 'Ключи API';
$_MODULE['<{decta}prestashop>decta_ed6445336472aef39084720adcf903b9'] = 'Открытый ключ';
$_MODULE['<{decta}prestashop>decta_952bf87c967660b7bbd4e1eb08cefc92'] = 'Секретный ключ';
$_MODULE['<{decta}prestashop>decta_1a0e4804ef5bb0eba3cfd6e4409082e0'] = 'Срок действия платежа (мин)';
$_MODULE['<{decta}prestashop>decta_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{decta}prestashop>payment_02cf064329cf953914ae3b1db3477b86'] = 'Оплата картой Visa / Mastercard';
$_MODULE['<{decta}prestashop>payment_return_091c355628c309a12c3e4858c6672582'] = 'Оплата прошла успешно, ваш заказ оформлен.';
$_MODULE['<{decta}prestashop>payment_return_d15feee53d81ea16269e54d4784fa123'] = 'Произошла ошибка при обработке вашего заказа. Свяжитесь с нашей';
$_MODULE['<{decta}prestashop>payment_return_66fcf4c223bbf4c7c886d4784e1f62e4'] = 'командой поддержки.';
$_MODULE['<{decta}prestashop>decta_intro_92c9bed0097b8e7bc21793217fb39d98'] = 'Этот модуль позволяет принимать безопасные платежи с помощью банковских карт.';
$_MODULE['<{decta}prestashop>payment_24b23a659df2c32a03b4fad4cf03eebd'] = 'Visa / MasterCard';
$_MODULE['<{decta}prestashop>payment_f95da1c548338c3b25654b98a1b9779f'] = 'Платеж прошел успешно';
